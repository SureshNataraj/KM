HM_Array1 = [
[120,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

1,
225,

"#ffffff",                     // font_color
"#000000",                     // mouseover_font_color
"#555982",                     // background_color
"#bdc6de",                     // mouseover_background_color
"#313952",                     // border_color
"#313952",                     // separator_color
1,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Escrow ","#",1,0,1],
["Manual Analysis ","#",1,0,1],
["Mass Analysis","#",1,0,1],
["Setup Escrow","#",1,0,1],
["Delete Escrow","#",1,0,1],
["SFB & BNK ","#",1,0,1],
["Escrow Advance ","#",1,0,1],
["S242 / P17D","#",1,0,1],
["F/C Report ","#",1,0,1],
["IL & MN ","#",1,0,1],
["Escrow Research","#",1,0,1],
["Title Check","#",1,0,1],
["Mails & Tasks","#",1,0,1],
["Spreading Shtg","#",1,0,1],
["Vendor Report","#",1,0,1],
["Supervisor Activities","#",1,0,1],
["Other Process ","#",1,0,1],
["General ","#",1,0,1],

]


HM_Array1_1 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["About Escrow","category_view.asp?cid=2",1,0,1],
["Internal Policies ","category_view.asp?cid=3",1,0,0],
["Process Maps","category_view.asp?cid=4",1,0,0],
["Job Aids","category_view.asp?cid=5",1,0,0],
["General","category_view.asp?cid=6",1,0,0]

]

HM_Array1_2 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=8",1,0,1],
["Insurance ","category_view.asp?cid=9",1,0,0],
["Exceptions","category_view.asp?cid=10",1,0,0],
["General","category_view.asp?cid=11",1,0,0]

]

HM_Array1_3 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=13",1,0,1],
["Insurance ","category_view.asp?cid=14",1,0,0],
["Exceptions","category_view.asp?cid=15",1,0,0],
["General","category_view.asp?cid=16",1,0,0]

]

HM_Array1_4 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=18",1,0,1],
["Insurance ","category_view.asp?cid=19",1,0,0],
["Exceptions","category_view.asp?cid=20",1,0,0],
["General","category_view.asp?cid=21",1,0,0]

]

HM_Array1_5 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=23",1,0,1],
["Insurance ","category_view.asp?cid=24",1,0,0],
["Exceptions","category_view.asp?cid=25",1,0,0],
["General","category_view.asp?cid=26",1,0,0]

]

HM_Array1_6 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=28",1,0,1],
["Insurance ","category_view.asp?cid=29",1,0,0],
["Exceptions","category_view.asp?cid=30",1,0,0],
["General","category_view.asp?cid=31",1,0,0]

]

HM_Array1_7 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Tax","category_view.asp?cid=33",1,0,1],
["Insurance ","category_view.asp?cid=34",1,0,0],
["Exceptions","category_view.asp?cid=35",1,0,0],
["General","category_view.asp?cid=36",1,0,0]

]


HM_Array1_8 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_9 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_10 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_11 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_12 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_13 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_14 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_15 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],

]

HM_Array1_16 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["General","category_view.asp?cid=38",1,0,1],
["Exception","category_view.asp?cid=39",1,0,0],
["Performance Matrix","category_view.asp?cid=39",1,0,0],

]

HM_Array1_17 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Posting Shortage","category_view.asp?cid=49",1,0,1],
["Balancing Surplus Checks","category_view.asp?cid=50",1,0,0],
["Ana Ovg to Pmts","category_view.asp?cid=53",1,0,0],

]

HM_Array1_18 = [
[180,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

290,
175,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Alltel Code","category_view.asp?cid=55",1,0,1],
["Tran Code","category_view.asp?cid=56",1,0,0],
["Irregular States","category_view.asp?cid=57",1,0,0]

]
