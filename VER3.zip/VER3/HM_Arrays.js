HM_Array1 = [
[140,
240,
123,
"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Software Product Bundles ","productvendorlist.asp?int_category=2&int_type=12&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Software Product Bundles",1,0,0],
["Technical Products","productvendorlist.asp?int_category=2&int_type=14&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Technical Products",1,0,0],
["Business Applications ","productvendorlist.asp?int_category=2&int_type=3&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Business Applications Software",1,0,0],
["Graphics and Web  ","productvendorlist.asp?int_category=2&int_type=7&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Graphics and Web Software",1,0,0],
["Music and Video  ","productvendorlist.asp?int_category=2&int_type=9&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Music and Video",1,0,0],
["Creative Writing ","productvendorlist.asp?int_category=2&int_type=5&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Creative Writing",1,0,0],
["Utility Software ","productvendorlist.asp?int_category=2&int_type=15&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Utility Software",1,0,0]
]


HM_Array2 = [
[155,                          
380,
123,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click


["Adobe TLP  ","Adobetlp.htm",1,0,0],
["Autodesk AOLP  ","AutodeskAOLP.htm",1,0,0],
["Corel VLP ","corelctl.htm",1,0,0],
["Macromedia VOLP  ","macromediavolp.htm",1,0,0],
["Microsoft Open  ","microsoftopen.htm",1,0,0],
["Symantec VLP  ","symantecvlp.htm",1,0,0]
]

HM_Array3 = [
[150,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

90,
123,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Input Devices ","productvendorlist.asp?int_category=2&int_type=8&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Input Devices",1,0,1],
["Storage Devices ","productvendorlist.asp?int_category=2&int_type=13&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Storage Devices",1,0,0],
["Calculators ","productvendorlist.asp?int_category=2&int_type=4&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Calculators",1,0,0],
["Digital Cameras ","productvendorlist.asp?int_category=2&int_type=6&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Digital Cameras",1,0,0],
["PDAs ","productvendorlist.asp?int_category=2&int_type=10&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;PDAs ",1,0,0]
]




HM_Array4 = [
[200,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

540,
123,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Eligibility ","aca_eligibility.htm",1,0,0],
["Product Bundle ","productvendorlist.asp?int_category=1&int_type=11&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Product Bundle ",1,0,0],
["Technical Software ","productvendorlist.asp?int_category=1&int_type=2&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Technical Software",1,0,0],
["Others ","productvendorlist.asp?int_category=1&int_type=1&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Others",1,0,0]

]



HM_Array5 = [
[130,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

430,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click

["Adobe TLP  ","Adobetlp.htm",1,0,0],
["Autodesk AOLP  ","AutodeskAOLP.htm",1,0,0],
["Corel VLP ","corelctl.htm",1,0,0],
["Macromedia VOLP  ","macromediavolp.htm",1,0,0],
["Microsoft Open  ","microsoftopen.htm",1,0,0],
["Symantec VLP  ","symantecvlp.htm",1,0,0]
]




HM_Array6 = [
[130,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

100,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Input Devices ","productvendorlist.asp?int_category=2&int_type=8&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Input Devices",1,0,1],
["Storage Devices ","productvendorlist.asp?int_category=2&int_type=13&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Storage Devices",1,0,0],
["Calculators ","productvendorlist.asp?int_category=2&int_type=4&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Calculators",1,0,0],
["Digital Cameras ","productvendorlist.asp?int_category=2&int_type=6&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;Digital Cameras",1,0,0],
["PDAs ","productvendorlist.asp?int_category=2&int_type=10&txt_desc=Hardware&nbsp;&gt;&gt;&nbsp;PDAs ",1,0,0]


]

HM_Array7 = [
[130,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

530,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Set up account  ","register.asp",1,0,1],
["Place order ","allproduct.asp",1,0,0],
["Request a quote ","requestquote.htm",1,0,0]

]

HM_Array8 = [
[130,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF
650,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Shipping","policy_shipping.htm",1,0,1],
["Payment Terms ","policy_payment.htm",1,0,0],
["Customer Care ","policy_customercare.htm",1,0,0]

]

HM_Array9 = [
[130,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

5,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Company Profile","aboutus.htm",1,0,1],
["Emro Advantage ","emroadvantage.htm",1,0,0],
["Contact  ","contact.htm",1,0,0]

]


HM_Array10 = [
[150,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

200,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
0,			       // right_to_left
0],			       // display_on_click

["Software Product Bundles ","productvendorlist.asp?int_category=2&int_type=12&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Software Product Bundles",1,0,0],
["Technical Products","productvendorlist.asp?int_category=2&int_type=14&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Technical Products",1,0,0],
["Business Applications ","productvendorlist.asp?int_category=2&int_type=3&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Business Applications Software",1,0,0],
["Graphics and Web  ","productvendorlist.asp?int_category=2&int_type=7&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Graphics and Web Software",1,0,0],
["Music and Video  ","productvendorlist.asp?int_category=2&int_type=9&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Music and Video",1,0,0],
["Creative Writing ","productvendorlist.asp?int_category=2&int_type=5&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Creative Writing",1,0,0],
["Utility Software ","productvendorlist.asp?int_category=2&int_type=15&txt_desc=Software&nbsp;&gt;&gt;&nbsp;Utility Software",1,0,0]
]




HM_Array11 = [
[150,                          // menu width

//"mouse_x_position - 5 ",       // left_position
//"mouse_y_position + 5",        // top_position
//#0099FF
//#9DD8FF

300,
120,

"#CCCCCC",                     // font_color
"#dadada",                     // mouseover_font_color
"#003251",                     // background_color
"#004777",                     // mouseover_background_color
"#000000",                     // border_color
"#000000",                     // separator_color
0,                             // top_is_permanent
0,                             // top_is_horizontal
0,                             // tree_is_horizontal
0,                             // position_under
1,                             // top_more_images_visible
1,                             // tree_more_images_visible
"null",                        // evaluate_upon_tree_show
"null",                        // evaluate_upon_tree_hide
1,			       // right_to_left
0],			       // display_on_click


["Eligibility ","aca_eligibility.htm",1,0,0],
["Product Bundle ","productvendorlist.asp?int_category=1&int_type=11&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Product Bundle ",1,0,0],
["Technical Software ","productvendorlist.asp?int_category=1&int_type=2&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Technical Software",1,0,0],
["Others ","productvendorlist.asp?int_category=1&int_type=1&txt_desc=Academic Software&nbsp;&gt;&gt;&nbsp;Others",1,0,0]

]
