To get started with this example, create a directory in your
Web root named /UploadWSC

Copy both files (default.asp and MetaBuilders.FileUp.wsc) to 
/UploadWSC.  Then, open your favorite Web browser and visit:

http://localhost/UploadWSC/Default.asp

When you upload a file using the example, it will be saved to the
/UploadWSC directory.  Have fun!